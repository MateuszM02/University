﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Klasa wszelkich obiektow, ktorych dotkniecie oznacza porazke
/// </summary>
public class Przeszkoda : RuchomyObiekt
{
    [SerializeField] private bool zabija = true;
    protected override void ChildCollisionEnter(Collision other) //jesli postac dotknela przeszkody
    {
        if (zabija) SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        //Gracz.transform.position = PozycjaOdrodzenia; //zacznij poziom od nowa
    }
}
