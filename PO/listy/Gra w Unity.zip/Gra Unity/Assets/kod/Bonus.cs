﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bonus : MonoBehaviour
{
    private enum RodzajBonusu
    {
        DoPredkosci, DoSkakania, DodatkowySkok
    }
    //domyslnym bonusem bedzie bonus do predkosci poruszania sie postaci
    [SerializeField] private RodzajBonusu rodzaj_bonusu = RodzajBonusu.DoPredkosci;
    //[SerializeField] private float moc_bonusu = 1;
    //----------------------------------------------------------------------------------------------------
    private void Start()
    {
        gameObject.name += rodzaj_bonusu.ToString();
    }
    private void OnTriggerEnter(Collider other) //zebrano bonus
    {
        Destroy(gameObject);
    }
}
