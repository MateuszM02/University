﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEngine.SceneManagement;

/// <summary>
/// Zdobycie przez postac obiektu klasy Moneta jest celem kazdego poziomu
/// </summary>
public class Moneta : MonoBehaviour
{
    [SerializeField] private bool konczy_poziom = true;
    private void OnCollisionEnter(Collision collision) //jesli postac dotknela monety
    {
        if(konczy_poziom)
            GameManager.NextLevel();
    }
}
