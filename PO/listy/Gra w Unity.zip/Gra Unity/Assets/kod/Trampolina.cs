﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Obiekty tej klasy dodaja mocy wszelkim cialom stalym, ktore je dotkna
/// </summary>
public class Trampolina : MojObiekt
{
    [SerializeField] private Vector3 moc = new Vector3(-10,10,0); //moc z jaka obiekt ma sie odbic od trampoliny
    protected override void ChildCollisionEnter(Collision other)
    {
        if (other.rigidbody != null) //jesli obiekt ma cialo stale
            other.rigidbody.AddForce(moc, ForceMode.VelocityChange); //to dodaj mu moc
    }
}
