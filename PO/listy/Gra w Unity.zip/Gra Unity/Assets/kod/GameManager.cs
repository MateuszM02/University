﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [SerializeField] protected GameObject PostacGracza;
    [SerializeField] private Vector3 PozycjaOdrodzenia; //pozycja, w ktorej odradza sie gracz po smierci
    private void Awake()
    {
        PostacGracza = GameObject.FindGameObjectWithTag("Player");
    }
    void Start()
    {
        PozycjaOdrodzenia = new Vector3(0,1,0); 
    }
    protected void Update()
    {
        if (PostacGracza.transform.position.y < -1)
            PoziomOdNowa();
    }

    //----------------------------------------------------------------------------------------------------
    
    public void PoziomOdNowa()
    {
        PostacGracza.transform.position = PozycjaOdrodzenia; //zacznij poziom od nowa
    }

    public static void NextLevel() //przejdz do nastepnego poziomu
    {
        int indeks = SceneManager.GetActiveScene().buildIndex; //indeks aktualnego poziomu
        if (indeks + 1 >= SceneManager.sceneCountInBuildSettings) //jesli aktualny poziom jest ostatni
            SceneManager.LoadScene(0); //zaladuj 1 poziom
        else SceneManager.LoadScene(++indeks); //w p.p. zaladuj nastepny poziom
    }

    public static void CzyZmianaPoziomu()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1)) //jesli nacisnieto '1', zmien poziom na 1
            SceneManager.LoadScene(0);
        else if (Input.GetKeyDown(KeyCode.Alpha2)) //jesli nacisnieto '2', zmien poziom na 2
            SceneManager.LoadScene(1);
        else if (Input.GetKeyDown(KeyCode.Alpha3)) //jesli nacisnieto '3', zmien poziom na 3
            SceneManager.LoadScene(2);
        else if (Input.GetKeyDown(KeyCode.Alpha4)) //jesli nacisnieto '4', zmien poziom na 4
            SceneManager.LoadScene(3);
        else if (Input.GetKeyDown(KeyCode.Alpha5)) //jesli nacisnieto '5', zmien poziom na 5
            SceneManager.LoadScene(4);
        else if (Input.GetKeyDown(KeyCode.Alpha6)) //jesli nacisnieto '6', zmien poziom na 6
            SceneManager.LoadScene(5);
    }
}
