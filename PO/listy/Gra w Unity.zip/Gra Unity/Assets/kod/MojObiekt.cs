﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Klasa bazowa dla wiekszosci obiektow w grze
/// </summary>
public class MojObiekt : MonoBehaviour//GameManager
{
    [SerializeField] protected Vector3 PozycjaStartowa;
    protected virtual void ChildCollisionEnter(Collision other) {}
    protected virtual void ChildCollisionExit(Collision other) {}

    //----------------------------------------------------------------------------------------------------

    protected void OnCollisionEnter(Collision other)
    {
        other.transform.parent = transform; //ulatwia korzystanie z ruchomych platform przez postac
        ChildCollisionEnter(other);
    }
    protected void OnCollisionExit(Collision other)
    {
        if (other.transform.parent != null && other.transform.parent.name == transform.name)
            other.transform.parent = null;
        ChildCollisionExit(other);
    }
}
