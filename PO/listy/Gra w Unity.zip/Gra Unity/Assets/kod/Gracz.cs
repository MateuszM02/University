﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Uzytkownik aplikacji porusza sie w grze obiektem klasy Gracz
/// </summary>
public class Gracz : MonoBehaviour
{
    [SerializeField] private LayerMask maska = default;
    [SerializeField] private float mnoznik_predkosci = 1;
    [SerializeField] private float mnoznik_skakania = 7;
    private int ile_skokow_bonusowych = 0;

    private bool skocz; //ustala, czy postac ma wykonac skok
    private Rigidbody cialo; //umozliwia interakcje fizyczne, jak np. plynne poruszanie sie

    //----------------------------------------------------------------------------------------------------

    void Start()
    {
        if(!TryGetComponent<Rigidbody>(out cialo)) Debug.LogError("Nie udalo sie zaladowac poziomu!");
        skocz = false; //postac nie ma samoczynnie wykonywac skokow
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow)) skocz = true; //jesli nacisnieto strzalke w gore, daj sygnal do skoku
        else if (Input.GetKeyDown(KeyCode.P))
        {
            if (transform.parent == null)
                Debug.Log("BRAK");
            else
                Debug.Log(transform.parent.name);
        }
        else GameManager.CzyZmianaPoziomu();
    }

    private void FixedUpdate()
    {
        float hInput = Input.GetAxis("Horizontal") * mnoznik_predkosci; //okresla o ile postac ma sie poruszyc w lewo lub prawo
        cialo.velocity = new Vector3(hInput, cialo.velocity.y); //porusza postac w lewo lub prawo
        //jesli postac jest w powietrzu i nie ma bonusowych skokow, nie skacz
        int ile_dotyka = Physics.OverlapSphere(transform.position+new Vector3(0,-0.5f,0), 0.1f, maska).Length;
        if (ile_skokow_bonusowych <= 0 && ile_dotyka == 0)   return;
        if (skocz) //jesli otrzymano sygnal do skoku
        {
            if (ile_dotyka == 0) ile_skokow_bonusowych--;
            cialo.AddForce(mnoznik_skakania * Vector3.up, ForceMode.VelocityChange); //skocz
            skocz = false; //usun sygnal do skoku
        }
    }

    private void OnTriggerEnter(Collider other) //DO POPRAWY! 
    {
        switch (other.name)
        {
            case "bonusDoPredkosci": mnoznik_predkosci *= 2; break;
            case "bonusDoSkakania": mnoznik_skakania *= 2; break;
            case "bonusDodatkowySkok": ile_skokow_bonusowych += 1; break;
            default: break;
        }
    }
}
