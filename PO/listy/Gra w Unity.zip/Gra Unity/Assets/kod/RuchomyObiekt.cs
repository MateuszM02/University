﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Podklasa klasy Obiekt, zawierajaca wszystkie obiekty ruchome oprocz gracza
/// </summary>
public class RuchomyObiekt : MojObiekt
{
    [SerializeField] protected Vector3 PozycjaKoncowa;
    [SerializeField] protected bool ruchomy = false;
    //dla true obiekt wykonuje animacje caly czas, dla false tylko jak postac na nim stoi
    [SerializeField] protected bool automatyczna_animacja = true;
    //okresla po jakim czasie od dotkniecia znika obiekt znikajacy
    [SerializeField] protected float Czas_Czekania = 1;
    //okresla, ile czasu trwa animacja ruchomego obiektu
    [SerializeField] protected float Czas_Animacji = 3;

    //----------------------------------------------------------------------------------------------------

    // Start is called before the first frame update
    void Start()
    {
        if (ruchomy && automatyczna_animacja)
            StartCoroutine(WykonajAnimacje(gameObject, PozycjaKoncowa, Czas_Animacji, true));
    }

    void FixedUpdate()
    {
        if (Czas_Animacji <= 0) return; //anti-glitch - czas wykonywania animacji musi byc liczba dodatnia
        else if (!ruchomy || !automatyczna_animacja) return;
        else UstalTraseAnimacji(false);
    }

    void UstalTraseAnimacji(bool czy_wraca)
    {
        if (transform.position == PozycjaKoncowa)
        { 
            StartCoroutine(WykonajAnimacje(gameObject, PozycjaStartowa, Czas_Animacji, czy_wraca));
        }
        else if (transform.position == PozycjaStartowa)
        {
            StartCoroutine(WykonajAnimacje(gameObject, PozycjaKoncowa, Czas_Animacji, czy_wraca));
        }
    }

    //----------------------------------------------------------------------------------------------------

    /// <summary>
    /// Wykonuje animacje poruszania sie obiektu z pozycji startowej do docelowej.
    /// </summary>
    /// <param name="obiekt">Obiekt, ktory ma zmienic lokalizacje</param>
    /// <param name="cel">Lokalizacja, do ktorej zmierza obiekt</param>
    /// <param name="czas_animacji">Czas, po ktorym obiekt ma dotrzec do lokalizacji docelowej</param>
    /// <returns></returns>
    IEnumerator WykonajAnimacje(GameObject obiekt, Vector3 cel, float czas_animacji, bool czy_wraca)
    {
        if (czas_animacji <= 0 || obiekt == null) yield return null; //anti-glitch - czas wykonywania animacji musi byc liczba dodatnia
        Vector3 startPosition = obiekt.transform.position;
        float czas = 0; //czas ktory uplynal od poczatku wykonywania animacji
        yield return new WaitForSeconds(Czas_Czekania); //czekaj x sekund
        while (obiekt.transform.position != cel) //dopoki obiekt nie osiagnal oczekiwanej pozycji
        {
            obiekt.transform.position = Vector3.Lerp(startPosition, cel, czas / czas_animacji);
            czas += Time.deltaTime; //zaktualizuj czas, ktory uplynal od poczatku wykonywania animacji
            yield return null;
        }
        if(czy_wraca)
        {
            czas = 0;
            while (obiekt.transform.position != startPosition) //dopoki obiekt nie osiagnal oczekiwanej pozycji
            {
                obiekt.transform.position = Vector3.Lerp(cel, startPosition, czas / czas_animacji);
                czas += Time.deltaTime; //zaktualizuj czas, ktory uplynal od poczatku wykonywania animacji
                yield return null;
            }
        }
        yield return null; //po wykonaniu animacji zaczekaj t sekund
    }

    //----------------------------------------------------------------------------------------------------

    protected override void ChildCollisionEnter(Collision collision)
    {
        if (!automatyczna_animacja)
            UstalTraseAnimacji(true);
    }
}
