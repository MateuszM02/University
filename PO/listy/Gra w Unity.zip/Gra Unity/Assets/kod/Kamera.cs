﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Klasa odpowiedzialna za kamere i jej ruch za postacia
/// </summary>
public class Kamera : GameManager
{
    [SerializeField] private Camera kamera; //kamera, ktora bedzie sledzic
    private Vector3 odleglosc = new Vector3(0,0,-5); //odleglosc od postaci, ktora kamera bedzie sledzic
    
    void Start()
    {
        kamera = Camera.main;
        PostacGracza = GameObject.Find("gracz");
        kamera.backgroundColor = new Color(0, 0, 0, 0); //ustala tlo na czarne
        kamera.clearFlags = CameraClearFlags.SolidColor;
        QualitySettings.vSyncCount = 1;
        Application.targetFrameRate = 60;
    }

    void LateUpdate()
    {
        //zaktualizuj pozycje kamery w oparciu o pozycje sledzonej postaci
        kamera.transform.position = PostacGracza.transform.position + odleglosc;
    }
}
