package obliczenia;

public abstract class Fun1 extends Dzialanie 
{
    public Fun1()
    {}
    public Fun1(Wyrazenie w)
    {
        super(w);
    }    
}
