package obliczenia;

public interface Obliczalny 
{
    public double oblicz();    
}
