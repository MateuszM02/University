package obliczenia;

public class E extends Stala
{
    public E()
    {
        this.wartosc = Math.E;
    }    
}
