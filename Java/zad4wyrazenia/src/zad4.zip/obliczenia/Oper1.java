package obliczenia;

public abstract class Oper1 extends Dzialanie
{
    public Oper1()
    {}
    public Oper1(Wyrazenie w)
    {
        super(w);
    }        
}
