package obliczenia;

public enum Priorytet 
{
    Potega,
    Mnozenie,
    Dodawanie    
}
