package obliczenia;

public class PI extends Stala 
{
    public PI()
    {
        this.wartosc = Math.PI;
    }    
}
