from myAgent import MyAgent
from c4 import Board
from c4 import AgentRandom, AgentMinMaxMC, AgentMC
from network import Network
from playerEnum import PlayerEnum
from train import Train

def game(agent_a, agent_b):
    b = Board()
    agents = { PlayerEnum.First.value: agent_a, PlayerEnum.Second.value: agent_b }
    who = PlayerEnum.First.value
    
    while not b.end():
        m = agents[who].best_move(b)
        b.apply_move(m) 
                          
        who = PlayerEnum.Other(who)
    
    #b.print() 
    #print (b.result)
    #print ()
    
    return b.result
    
def duel(agent_a, agent_b, N):
    score = { PlayerEnum.First.value: 0, PlayerEnum.Second.value: 0, PlayerEnum.Neither.value: 0 }
    
    for i in range(N):
        r1 = game(agent_a, agent_b)
        score[r1] += 1
        print(f"{i+1} of {N}: {r1} won first game")
        r2 = game(agent_b, agent_a)
        score[r2] += 1
        print(f"{i+1} of {N}: {r2} won second game")
    
    for k in score:
        score[k] /= (2*N)
    print (f'{agent_a.name}: {score[PlayerEnum.First.value]},', end=" ") 
    print(f'{agent_b.name}: {score[PlayerEnum.Second.value]},', end=" ") 
    print(f'Draw: {score[PlayerEnum.Neither.value]}')
        
if __name__ == '__main__':
    A = AgentRandom()
    #A = AgentMC(10)    
    #B = AgentMC(10)
    #B = AgentMinMaxMC(3,10)
    training = Train(network=Network("cuda"), epochs=50, learning_rate=0.0002, momentum=0.9, 
                     weight_decay=0.0005, nesterov=True, batch_size=10)
    training.fit()
    B = MyAgent(training.network, PlayerEnum.Second.value)

    duel(A, B, 5)