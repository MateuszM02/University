from c4 import Board
from minMax import MinMax
from network import Network

class MyAgent:
    def __init__(self, network: Network, whoAmI: int, depth: int = 3):
        self.name = f'MyAgent'
        self.network = network
        self.whoAmI = whoAmI
        self.depth = depth
    
    def best_move(self, b: Board):
        minmax = MinMax(self.depth, b, self.network, self.whoAmI)
        move = minmax.best_move()
        if move is not None:
            return move
        else:
            raise Exception("No available moves!")