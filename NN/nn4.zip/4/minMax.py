from copy import deepcopy

from c4 import Board
from network import Network
from playerEnum import PlayerEnum

class MinMax:
    def __init__(self, depth: int, board: Board, network_: Network, whoAmI_: int):
        self.depth = depth
        self.board = board
        self.network_ = network_
        self.whoAmI_ = whoAmI_

    def evaluate(self):
        # Use the neural network to evaluate the state value
        output_tensor = self.network_.forward(Network.encodeBoard(self.board, self.network_.device))
        ppb_tensor = self.network_.softmax(output_tensor)
        return ppb_tensor[0][self.whoAmI_]

    def sort_children(self, moves):
        # Evaluate and sort the moves based on the neural network's output
        evaluated_moves = []
        for m in moves:
            new_board = deepcopy(self.board)
            new_board.apply_move(m)
            evaluation = self.evaluate()
            evaluated_moves.append((m, evaluation))

        # Sort moves based on evaluation, descending for maximizing player, ascending for minimizing player
        is_reversed = self.whoAmI_ == PlayerEnum.First.value
        evaluated_moves.sort(key=lambda x: x[1], reverse=is_reversed)
        return [move for move, _ in evaluated_moves]

    def minmax(self, alpha: float, beta: float, maximizing_player: bool):
        if self.depth == 0 or self.board.end():
            return self.evaluate()

        moves = self.sort_children(self.board.get_moves())

        if maximizing_player:
            max_eval = float('-inf')
            for m in moves:
                new_board = deepcopy(self.board)
                new_board.apply_move(m)
                child = MinMax(self.depth - 1, new_board, self.network_, self.whoAmI_)
                eval = child.minmax(alpha, beta, False)
                max_eval = max(max_eval, eval)
                alpha = max(alpha, eval)
                if beta <= alpha:
                    break  # Prune remaining branches
            return max_eval
        else:
            min_eval = float('inf')
            for m in moves:
                new_board = deepcopy(self.board)
                new_board.apply_move(m)
                child = MinMax(self.depth - 1, new_board, self.network_, self.whoAmI_)
                eval = child.minmax(alpha, beta, True)
                min_eval = min(min_eval, eval)
                beta = min(beta, eval)
                if beta <= alpha:
                    break  # Prune remaining branches
            return min_eval

    def best_move(self):
        best_eval = float('-inf')
        best_move = None
        alpha, beta = float('-inf'), float('inf')
        moves = self.sort_children(self.board.get_moves())
        for m in moves:
            new_board = deepcopy(self.board)
            new_board.apply_move(m)
            child = MinMax(self.depth - 1, new_board, self.network_, self.whoAmI_)
            eval = child.minmax(alpha, beta, False)
            if eval > best_eval:
                best_eval = eval
                best_move = m
            alpha = max(alpha, eval)
        return best_move
