import torch
import torch.nn as nn
import torch.nn.functional as F

from c4 import DX, DY, Board
CHANNELS = 3

class Network(nn.Module):
	def __init__(self, device: str):
		super().__init__()
		self.device = device
		
		# define the layers

		# conv
		self.initial_conv = nn.Conv2d(CHANNELS, 128, kernel_size=3, stride=1, padding=1, bias=True)
		self.initial_bn = nn.BatchNorm2d(128)

		# Res block 1
		self.res1_conv1 = nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1, bias=False)
		self.res1_bn1 = nn.BatchNorm2d(128)
		self.res1_conv2 = nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1, bias=False)
		self.res1_bn2 = nn.BatchNorm2d(128)

		# Res block 2
		self.res2_conv1 = nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1, bias=False)
		self.res2_bn1 = nn.BatchNorm2d(128)
		self.res2_conv2 = nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1, bias=False)
		self.res2_bn2 = nn.BatchNorm2d(128)

		# value head
		self.value_conv = nn.Conv2d(128, 3, kernel_size=1, stride=1, bias=True)
		self.value_bn = nn.BatchNorm2d(3)
		self.value_fc = nn.Linear(3*DY*DX,32)
		self.value_head = nn.Linear(32, 3)
		self.softmax = nn.Softmax(dim=1)

		self.to(device)

	def forward(self, X: torch.Tensor):
		# define connections between the layers
		# x will be shape (CHANNELS, DY, DX)

		# add dimension for batch size
		X = X.view(-1, CHANNELS, DY, DX)
		X = F.relu(self.initial_bn(self.initial_conv(X)))

		# Res Block 1
		X = F.relu(self.res1_bn1(self.res1_conv1(X)))
		X = F.relu(self.res1_bn2(self.res1_conv2(X)))
		
		# Res Block 2
		X = F.relu(self.res2_bn1(self.res2_conv1(X)))
		X = F.relu(self.res2_bn2(self.res2_conv2(X)))
		
		# value head
		X = F.relu(self.value_bn(self.value_conv(X)))
		X = X.view(-1, CHANNELS*DY*DX)
		X = F.relu(self.value_fc(X))
		X = self.value_head(X)

		return X
	
	def encodeBoard(b: Board, device: str):
		# Initialize board tensor with 3 channels - first player, second player, empty fields
		board_tensor = torch.zeros((CHANNELS, DY, DX), dtype=torch.float32, device=device)	
		for y in range(DY):
			for x in range(DX):
				value = b.board[y][x]
				board_tensor[value, y, x] = 1.0
		return board_tensor