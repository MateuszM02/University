from enum import Enum

class PlayerEnum(Enum):
    First = 0
    Second = 2
    Neither = 1

    # char -> PlayerEnum with PlayerEnum.from(char)
    @classmethod
    def From(cls, char_int):
        obj = object.__new__(cls)
        match char_int:
            case 'A': obj._value_ = cls.First.value
            case 'B': obj._value_ = cls.Second.value
            case 'D': obj._value_ = cls.Neither.value
            case _: raise ValueError(f"No PlayerEnum member associated with char: '{char_int}'")
        return obj
    
    # int -> int of other player
    @classmethod
    def Other(cls, intv):
        match intv:
            case cls.First.value: return cls.Second.value
            case cls.Second.value: return cls.First.value
            case _: raise ValueError(f"Can't change '{intv}' to opposite player")