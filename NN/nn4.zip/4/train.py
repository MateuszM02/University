import time
import torch
from torch.utils.data import DataLoader, TensorDataset
from torch.optim import SGD

from c4 import Board
from playerEnum import PlayerEnum
from network import Network

INIT_PATH = "Data/games3.txt"
DATA_LOADER_PATH = "Data/data_loader.pth"
STATE_PATH = "Data/train_checkpoint.pth"

GAMES = 1_000
SKIP_RATIO = 0.5

class Train:
    def __init__(self, network: Network, epochs: int = 100, 
                 learning_rate: float = 0.01, momentum: float = 0.0, 
                 weight_decay: float = 0.0, nesterov: bool = False, batch_size: int = 16):
        self.network = network
        self.train_loader = None
        self.start_epoch = 0

        self.epochs = epochs
        self.learning_rate = learning_rate
        self.momentum = momentum
        self.weight_decay = weight_decay
        self.batch_size = batch_size
        self.nesterov = nesterov
        self.optimizer = SGD(params=self.network.parameters(), lr=self.learning_rate, 
                             momentum=self.momentum, weight_decay=self.weight_decay, nesterov=self.nesterov)
        self.criterion = torch.nn.CrossEntropyLoss()
        
        # Load saved network state if available
        self.load_saved_state()

    def load_saved_state(self):
        try:
            checkpoint = torch.load(DATA_LOADER_PATH)
            self.train_loader = checkpoint['train_loader']
            print("Loaded saved data loader.")
        except FileNotFoundError:
            print("No saved data loader. Creating one from scratch.")
            self.train_loader = self.load_and_init(INIT_PATH)
        
        try:
            checkpoint = torch.load(STATE_PATH)
            self.network.load_state_dict(checkpoint['network_state_dict'])
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            self.start_epoch = checkpoint['start_epoch']
            print("Loaded saved network state.")
        except FileNotFoundError:
            print("No saved network state found. Starting training from scratch.")

    # load dataset for completely untrained network
    def load_and_init(self, file_path: str):

        tstart = time.time()
        # Load data from file
        games_data = []
        with open(file_path, 'r') as file:
            for _ in range(GAMES):
                line = file.readline()
                if not line:
                    break

                # Skip first letter 'S'
                game_moves, winner_char = line[1:-2], line[-2]
                # Get channel index of winner
                winner_label = PlayerEnum.From(winner_char).value
                
                board = Board()
                GAME_LENGTH = len(game_moves)
                NO_CHECK_STATES = int(GAME_LENGTH * SKIP_RATIO)

                for i in range(NO_CHECK_STATES): # for first x game states we don't add to dataset - time saving
                    move = int(game_moves[i])
                    board.apply_move(move)
                
                for i in range(NO_CHECK_STATES, GAME_LENGTH): # we add remaining game states to dataset
                    move = int(game_moves[i])
                    board.apply_move(move)
                    # Encode current board state
                    board_state_encoded = Network.encodeBoard(board, self.network.device)
                    games_data.append((board_state_encoded, winner_label))
                
        states = torch.stack([item[0] for item in games_data])
        winners = torch.tensor([item[1] for item in games_data], dtype=torch.long, device=self.network.device)

        dataset = TensorDataset(states, winners)
        train_loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
        
        # save train loader to file for quicker data initialization next time
        torch.save({ 'train_loader': self.train_loader }, DATA_LOADER_PATH)
        print(f"Creating data loader took {time.time() - tstart} seconds")
        return train_loader

    def fit(self):
        if self.train_loader is None:
            self.train_loader = self.load_and_init(INIT_PATH)  # Load data if not loaded
        
        self.network.train()
        for epoch in range(self.start_epoch, self.epochs):
            avg_loss = 0.0
            for i, data in enumerate(self.train_loader, 0):
                inputs, labels = data
                inputs, labels = inputs.to(self.network.device), labels.to(self.network.device)

                self.optimizer.zero_grad()

                # Run forward method
                outputs = self.network(inputs)

                # Calculate loss and backpropagate
                loss = self.criterion(outputs, labels)
                avg_loss += loss
                loss.backward()

                # Update weights
                self.optimizer.step()

            div = float(GAMES) / self.batch_size
            print(f'Epoch {epoch + 1}, Loss: {avg_loss / div}')

            # Save network state at the end of each epoch
            torch.save({
                'start_epoch': epoch + 1,
                'network_state_dict': self.network.state_dict(),
                'optimizer_state_dict': self.optimizer.state_dict()
            }, STATE_PATH)

        self.network.eval()
        print('Training ended')