﻿using Sklep.Helpers;
using System.ComponentModel.DataAnnotations;

namespace Sklep.Models
{
    public class _User
    {
        // name of user, unique value
        [Key]
        [Required]
        [MaxLength(30)]
        public string Name { get; set; } = null!;

        [Required]
        [MaxLength(255)]
        [EmailAddress]
        public string Email { get; set; } = null!;

        // role of logged website user - user or admin
        [Required]
        [MaxLength(8)]
        public string UserRole 
        { 
            get { return _role; } 
            set { if (ROLE.IsLegal(value)) _role = value; } 
        }
        private string _role = null!;
    }
}
