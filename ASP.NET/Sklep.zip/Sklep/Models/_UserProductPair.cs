﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Sklep.Models
{
    [PrimaryKey(nameof(Username), nameof(Productname))]
    public class _UserProductPair(string username = null!, string productname = null!, int amount = 1)
    {
        [Required]
        [MaxLength(30)]
        public string Username { get; set; } = username;
        
        [Required]
        [MaxLength(64)]
        public string Productname { get; set; } = productname;

        // amount of product pieces user took
        [Required]
        public int Amount { get; set; } = amount;
    }
}
