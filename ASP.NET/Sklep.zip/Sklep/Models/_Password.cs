﻿using OtpNet;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Security.Cryptography;

namespace Sklep.Models
{
    /// <summary>
    /// Class to store info about User's name and password details
    /// </summary>
    /// <param name="saltLength">Length of salt used in hashing proccess, has to be in range [4, 64] with default being 8 </param>
    /// <param name="OtpKeyLength">Length of key used in OTP verification (Admin only), has to be in range [6, 64] with default being 16 </param>
    public class _Password([Range(4, 64)] int saltLength, [Range(6, 64)] int OtpKeyLength)
    {
        // name of user, unique value
        [Key]
        [Required]
        [MaxLength(30)]
        public string Username { get; set; } = null!;

        // password of user, stored as hash
        [Required]
        [DataType(DataType.Password)]
        [MaxLength(64)]
        public string Password { get; set; } = null!;

        // salt to make unhashing even harder
        [Required]
        [Length(4, 64)]
        public string Salt { get; set; } = GenerateRandomSalt(saltLength);

        // OTP key for admin login
        [Length(6, 64)]
        public byte[] OtpKey { get; set; } = KeyGeneration.GenerateRandomKey(OtpKeyLength);

        // amount of iterations during hashing
        private readonly int Iterations = 8;

        public _Password() : this(8, 16) { }

        private static string GenerateRandomSalt(int length)
        {
            var sb = new StringBuilder();
            var random = new Random();
            for (int i = 0; i < length; i++)
            {
                int index = random.Next(0, 62); // 0-9, A-Z, a-z
                char c = IntToChar(index);
                sb.Append(c);
            }
            return sb.ToString();
        }

        private static char IntToChar(int index)
        {
            return (char)(index < 10 ? index + '0' : // 0-9
                          index < 36 ? index - 10 + 'A' : // A-Z
                          index - 36 + 'a'); //a-z
        }

        /// <summary>
        /// Hash your password using SHA256 algorithm with Salt and Iterations equal to instance values
        /// </summary>
        /// <param name="password">explicit form of password you want to hash</param>
        /// <returns>password in hashed form</returns>
        public string Hash(string password)
        {
            for (int i = 0; i < Iterations; i++)
            {
                password += Salt;
                byte[] hashBuilder = Encoding.UTF8.GetBytes(password);
                hashBuilder = SHA256.HashData(hashBuilder);
                password = Encoding.UTF8.GetString(hashBuilder);
            }
            return password;
        }
    }
}
