﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Sklep.Models
{
    // it is temporary log in structure so make sure it doesnt have it's own table in database
    [NotMapped]
    public class LogInModel
    {
        [Required]
        [MaxLength(30)]
        public string Username { get; set; } = null!;
        [Required]
        [DataType(DataType.Password)]
        [MinLength(6)]
        [MaxLength(64)]
        public string Password { get; set; } = null!;
    }
}
