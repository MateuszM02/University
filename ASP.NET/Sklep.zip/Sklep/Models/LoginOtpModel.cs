﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Sklep.Models
{
    // it is temporary log in structure so make sure it doesnt have it's own table in database
    [NotMapped]
    public class LoginOtpModel(string username, byte[] otpKey)
    {
        [Required]
        [MaxLength(30)]
        public string Username { get; set; } = username;
        // no need for Password as we already verified it in User/LoginVerify
        // OTP code given by user
        [MaxLength(6)]
        public string OtpCode { get; set; } = null!;
        // real OTP key for admin login
        [Required]
        [Length(6, 64)]
        public byte[] OtpKey { get; set; } = otpKey;

        public LoginOtpModel() : this(null!, null!) { }
    }
}
