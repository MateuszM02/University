﻿using System.ComponentModel.DataAnnotations;

namespace Sklep.Models
{
    public class _Product
    {
        [Key]
        [Required]
        [MaxLength(64)]
        public string Name { get; set; } = null!;
        public string Description { get; set; } = null!;
        public int AmountAvailable { get; set; }
        public double Cost { get; set; }
        public double DeliveryCost { get; set; }
        public string ImageSource { get; set; } = null!;
        // public ICollection<byte[]> Images { get; set; } = null!;
    }
}
