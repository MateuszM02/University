﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Sklep.Models
{
    // it is temporary sign up structure so make sure it doesnt have it's own table in database
    [NotMapped]
    public class SignUpModel
    {
        [Required]
        [MaxLength(30)]
        public string Username { get; set; } = null!;
        [Required]
        [MaxLength(255)]
        [EmailAddress]
        public string Email { get; set; } = null!;
        [Required]
        [DataType(DataType.Password)]
        [MinLength(6)]
        [MaxLength(64)]
        public string Password { get; set; } = null!;
        [Required]
        [DataType(DataType.Password)]
        [MinLength(6)]
        [MaxLength(64)]
        [Compare(nameof(Password))]
        public string ConfirmPassword { get; set; } = null!;
    }
}
