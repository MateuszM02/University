using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Sklep.Helpers;

// Add-Migration [InitialCreate]
// Update-Database

var builder = WebApplication.CreateBuilder(args);
var services = builder.Services;

services.AddControllersWithViews();

// Add user authentication
services
    .AddAuthentication(options =>
    {
        options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    })
    .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
    {
        options.AccessDeniedPath = PATHS.AccessDenied;
        options.SlidingExpiration = true;
        options.Cookie.SameSite = SameSiteMode.Unspecified;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    });
//.AddGoogle(GoogleDefaults.AuthenticationScheme, googleOptions =>
//{
//    googleOptions.ClientId = "331448897176-580tk0c49mklp3ipfrblg4h4k7508qem.apps.googleusercontent.com";
//    googleOptions.ClientSecret = "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";
//    googleOptions.CorrelationCookie.SameSite = SameSiteMode.None;
//    googleOptions.CorrelationCookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
//});

// Add database context
services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(PATHS.ConnectionString));

// services.AddHttpContextAccessor();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var _services = scope.ServiceProvider;

    var context = _services.GetRequiredService<AppDbContext>();
    context.Database.EnsureCreated();
    //DbInitializer.Initialize(context);
}

app.UseStaticFiles()
    .UseRouting()
    .UseAuthentication()
    .UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Guest}/{action=Index}/{id?}");

app.Run();