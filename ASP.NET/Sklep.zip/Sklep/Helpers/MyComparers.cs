﻿using ProductInfo = System.Tuple<string, Sklep.Models._Product, int>;

namespace Sklep.Helpers
{
    /// <summary>
    /// Generic comparer which allows you to sort elements of class based on its field
    /// </summary>
    /// <typeparam name="FieldType">type of field you want to sort by your class instances</typeparam>
    /// <typeparam name="ClassType">type of class your elements are</typeparam>
    /// <param name="comparison">your class implementation of Compare method</param>
    /// <param name="fieldFunc">function returning field of class you want to sort by, best in form: instance => instance.fieldname</param>
    public class GenericComparer<FieldType, ClassType>
        (Func<ClassType, FieldType> fieldFunc, Comparison<FieldType> comparison) : IComparer<ClassType>
    {
        private readonly Comparer<ClassType> comparer = Comparer<ClassType>.Create((x, y) => comparison(fieldFunc(x), fieldFunc(y)));
        public int Compare(ClassType? x, ClassType? y) =>  comparer.Compare(x, y);
    }

    public static class MyComparer
    {
        static readonly Comparison<string> lessOrEqual = (x, y) => string.Compare(y, x);

        public static readonly IComparer<ProductInfo> ascUsernameComparer = new GenericComparer<string, ProductInfo>(t => t.Item1, string.Compare);
        public static readonly IComparer<ProductInfo> descUsernameComparer = new GenericComparer<string, ProductInfo>(t => t.Item1, lessOrEqual);
        public static readonly IComparer<ProductInfo> ascProductnameComparer = new GenericComparer<string, ProductInfo>(t => t.Item2.Name, string.Compare);
        public static readonly IComparer<ProductInfo> descProductnameComparer = new GenericComparer<string, ProductInfo>(t => t.Item2.Name, lessOrEqual);
        public static readonly IComparer<ProductInfo> ascAmountComparer = new GenericComparer<int, ProductInfo>(t => t.Item3, (x, y) => x.CompareTo(y));
        public static readonly IComparer<ProductInfo> descAmountComparer = new GenericComparer<int, ProductInfo>(t => t.Item3, (x, y) => y.CompareTo(x));
    }
}
