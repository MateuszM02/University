﻿using Sklep.Models;
using Microsoft.EntityFrameworkCore;

namespace Sklep.Helpers
{
    /// <summary>
    /// Class that stores important paths
    /// </summary>
    public static class PATHS
    {
        public const string MainPage = $"/{ROLE.Guest}\\Index"; // must have Guest controller with Index GET method
        public const string AccessDenied = $"/{ROLE.Guest}\\AccessDenied"; // must have Guest controller with AccessDenied GET method
        public const string ShowBasket = $"/{ROLE.User}\\ShowBasket"; // must have User controller with ShowBasket GET method
        public const string ConnectionString =
            "Server=(localdb)\\mssqllocaldb;Database=Sklep;Trusted_Connection=True;";
        public const string SearchKey = "SearchKey";
        public const string UserOrdersView = "ShowOrders";
    }

    public static class CssNames
    {
        public const string btnForm = "btnForm";
        public const string btnWideLine = "btnWideLine";
        public const string btn2Lines = "btn2Lines";
        public const string btn2WideLines = "btn2WideLines";
    }

    /// <summary>
    /// Stores names of legal user types and method that checks whether role is legal
    /// </summary>
    public static class ROLE
    {
        public static bool IsLegal(string role)
        {
            return role switch
            {
                User or Admin => true,
                _ => false,
            };
        }

        public const string Guest = "Guest"; // illegal role, but need const value to not make misspells
        public const string User = "User";
        public const string Admin = "Admin";
        public const string UserOrAdmin = "User, Admin";
    }

    /// <summary>
    /// Class that allows C# to link with local database
    /// </summary>
    public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
    {

        // Override this method to configure the database provider and connection string
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(PATHS.ConnectionString);
        }

        public virtual DbSet<_User> Users { get; set; } = null!;
        public virtual DbSet<_Product> Products { get; set; } = null!;
        public virtual DbSet<_Password> Passwords { get; set; } = null!;
        public virtual DbSet<_UserProductPair> UserProducts { get; set; } = null!;
    }
}