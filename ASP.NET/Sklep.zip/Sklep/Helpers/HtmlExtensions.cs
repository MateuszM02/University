﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Sklep.Helpers
{
    public static class HtmlExtensions
    {
        /// <summary>
        /// Html extension that creates form with button inside div
        /// </summary>
        /// <param name="_"></param>
        /// <param name="actionName">IActionResult Method you want to call</param>
        /// <param name="controllerName">Controller in which that method exists</param>
        /// <param name="buttonText">Text to display inside button</param>
        /// <returns></returns>
        public static HtmlString FormCreate(this IHtmlHelper _, string actionName = "Index", string controllerName = ROLE.Guest, string buttonText = "Go back", string btnClassName= "btnForm", string formMethod="get")
        {
            string divString = $"    <div>\r\n    <button type=\"submit\" class=\"{btnClassName}\">{buttonText}</button>\r\n    </div>\r\n    ";
            string formString = $"<form action=\"/{controllerName}/{actionName}\" method=\"{formMethod}\">\r\n{divString}</form>";
            return new HtmlString(formString);
        }

        /// <summary>
        /// Html extension that creates submit button inside div
        /// </summary>
        /// <param name="_"></param>
        /// <param name="buttonText">Text to display inside button</param>
        /// <returns></returns>
        public static HtmlString ButtonSubmit(this IHtmlHelper _, string buttonText = "Go back", string btnClassName = "btnForm")
        {
            string divString = $"<div>\r\n    <button type=\"submit\" class=\"{btnClassName}\">{buttonText}</button>\r\n</div>\r\n";
            return new HtmlString(divString);
        }
    }
}
