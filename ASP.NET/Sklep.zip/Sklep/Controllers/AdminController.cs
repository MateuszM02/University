﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sklep.Helpers;
using Sklep.Models;
using ProductInfo = System.Tuple<string, Sklep.Models._Product, int>;

namespace Sklep.Controllers
{
    [Authorize(Roles = ROLE.Admin)]
    public class AdminController : Controller
    {
        private readonly AppDbContext _dbContext;
        public AdminController(AppDbContext context)
        {
            _dbContext = context;
            _dbContext.SaveChanges();
        }

        public IActionResult Index()
        {
            List<_Product> products = [.. _dbContext.Products];
            return View(products);
        }

        // 1. Show list of users ------------------------------------------------------------------
        [HttpGet]
        public IActionResult ShowUsers()
        {
            return View( _dbContext.Users.ToList() );
        }

        // 2. Searching shop products -------------------------------------------------------------
        // 2.1 show products which meets criteria
        [HttpPost]
        public IActionResult Search()
        {
            List<_Product> foundProducts = _dbContext.Products
                .Where(MeetsPhrase).ToList();
            return View(nameof(Index), foundProducts);
        }

        // 2.2 Check if product name or description contains searched phrase
        public bool MeetsPhrase(_Product p)
        {
            string searchedPhrase = Request.Form[PATHS.SearchKey]!;
            return p.Name.Contains(searchedPhrase, StringComparison.OrdinalIgnoreCase) ||
                p.Description.Contains(searchedPhrase, StringComparison.OrdinalIgnoreCase);
        }

        // 3. Operations on products --------------------------------------------------------------
        // 3.1 Add new product to the website
        [HttpGet]
        public IActionResult AddProduct()
        {
            return View(new _Product());
        }

        [HttpPost]
        public IActionResult AddProduct(_Product newProduct)
        {
            if (_dbContext.Products.Any(p => p.Name == newProduct.Name))
            {
                ModelState.AddModelError("", "This product name is already taken.");
            }
            else // product name unique, add to database
            {
                _dbContext.Products.Add(newProduct);
                _dbContext.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }

        // 3.2 Modify existing product on the website
        // show product list with option to select which to modify/remove
        [HttpGet]
        public IActionResult ChangeProduct()
        {
            return View(_dbContext.Products.ToList());
        }

        // show product details so that they can be changed
        [HttpGet]
        public IActionResult ModifyProduct(string name)
        {
            _Product? productToModify = _dbContext.Products.FirstOrDefault(p => p.Name == name);
            if (productToModify != null)
                return View(productToModify);
            ModelState.AddModelError("", "Product with given name doesn't exist");
            return RedirectToAction(nameof(Index));
        }

        // modify product with new data
        [HttpPost]
        public IActionResult ModifyProduct(_Product modifiedProduct)
        {
            _Product? productWithSameKey = _dbContext.Products.FirstOrDefault(p => p.Name == modifiedProduct.Name);
            if (productWithSameKey == null)
            {
                ModelState.AddModelError("", "There is no product with given name.");
            }
            else // product name exists, update it's non-key values in database
            {
                try
                {
                    _dbContext.Products.Remove(productWithSameKey);
                    _dbContext.SaveChanges();
                    _dbContext.Products.Add(modifiedProduct);
                    _dbContext.SaveChanges();
                }
                catch (DbUpdateException ex) // handle database update exceptions
                {
                    ModelState.AddModelError("", $"An error occurred while modifying the product: {ex.Message}");
                }
            }
            return RedirectToAction(nameof(Index));
        }

        // 3.3 Delete existing product from the website
        // remove product with given unique name
        [HttpGet]
        public IActionResult DeleteProduct(string name)
        {
            try
            {
                _Product productToDelete = _dbContext.Products.First(p => p.Name == name);
                _dbContext.Products.Remove(productToDelete);
                IEnumerable<_UserProductPair> pairsToBeRemoved = _dbContext.UserProducts
                    .Where(upp => upp.Productname == productToDelete.Name);
                _dbContext.UserProducts.RemoveRange(pairsToBeRemoved);
                _dbContext.SaveChanges();
            }
            catch (Exception ex) // handle exceptions
            {
                ModelState.AddModelError("", $"An error occurred while deleting the product: {ex.Message}");
            }
            return RedirectToAction(nameof(Index));
        }

        // 4. Looking at users' orders ------------------------------------------------------------
        
        /// <summary>
        /// Selector returning user's name, product he put into basket and amount of that product
        /// </summary>
        /// <param name="upp">User-Product pair</param>
        public ProductInfo SelectProductInfo(_UserProductPair upp)
        {
            return new ProductInfo( upp.Username, 
                                    _dbContext.Products.First(p => p.Name == upp.Productname), 
                                    upp.Amount);
        }

        /// <summary>
        /// Returns view showing User-Product pairs that meet certain criteria
        /// </summary>
        /// <param name="predicate">Function with 1 argument of type _UserProductPair 
        /// which returns bool determining whether argument should be included or not</param>
        /// <param name="comparer">Comparer with 2 arguments of type ProductInfo which determines their order</param>
        [HttpPost]
        public IActionResult ShowUserOrdersWhere(Func<_UserProductPair, bool> predicate, IComparer<ProductInfo>? comparer = null)
        {
            List<_UserProductPair> pairs =
            [
                .. _dbContext.UserProducts
                    .Where(predicate)
            ];
            List<ProductInfo> userBasket = pairs.Select(SelectProductInfo).ToList();
            if (comparer != null)
                userBasket.Sort(comparer);
            return View(PATHS.UserOrdersView, userBasket);
        }

        /// <summary>
        /// Returns view showing all User-Product pairs
        /// </summary>
        [HttpGet]
        public IActionResult ShowAllUserOrders()
        {
            List<_UserProductPair> pairs = [.. _dbContext.UserProducts];
            List<ProductInfo> userBasket = pairs.Select(SelectProductInfo).ToList();
            userBasket.Sort(MyComparer.ascUsernameComparer);
            return View(PATHS.UserOrdersView, userBasket);
        }

        /// <summary>
        /// Returns view showing User-Product pairs of specific user
        /// </summary>
        /// <param name="username">username of user which products you want to see</param>
        [HttpPost]
        public IActionResult ShowUserOrdersWhere(string username)
        {
            return ShowUserOrdersWhere(upp => upp.Username == username);
        }

    }
}
