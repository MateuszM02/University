﻿using Microsoft.AspNetCore.Mvc;
using Sklep.Models;
using Sklep.Helpers;
using Microsoft.AspNetCore.Authorization;
using ProductPair = System.Tuple<Sklep.Models._Product, int>;

namespace Sklep.Controllers
{
    [Authorize(Roles = ROLE.User)]
    public class UserController : Controller
    {
        private readonly AppDbContext _dbContext;
        public UserController(AppDbContext context) 
        {
            _dbContext = context;
            _dbContext.SaveChanges();
        }

        // 1. Show user version of shop -----------------------------------------------------------
        public IActionResult Index()
        {
            List<_Product> products = [.. _dbContext.Products];
            return View(products);
        }

        // 2. Searching shop products -------------------------------------------------------------
        // 2.1 show products which meets criteria
        [HttpPost]
        public IActionResult Search()
        {
            List<_Product> foundProducts = _dbContext.Products
                .Where(MeetsPhrase).ToList();
            return View(nameof(Index), foundProducts);
        }

        // 2.2 Check if product name or description contains searched phrase
        public bool MeetsPhrase(_Product p)
        {
            string searchedPhrase = Request.Form[PATHS.SearchKey]!;
            return p.Name.Contains(searchedPhrase, StringComparison.OrdinalIgnoreCase) ||
                p.Description.Contains(searchedPhrase, StringComparison.OrdinalIgnoreCase);
        }

        // 3. Add product to shopping basket ------------------------------------------------------
        [HttpGet]
        public IActionResult AddToCart(string name)
        {
            _Product? product = _dbContext.Products.FirstOrDefault(p => p.Name == name);
            if (product == null)
                return RedirectToAction(nameof(Index));

            string username = User.Identity!.Name!;
            _UserProductPair? upp = _dbContext.UserProducts
                .FirstOrDefault(up => up.Username == username && up.Productname == product.Name);

            if (upp == null) // first time this user added this product to his basket
            {
                upp = new _UserProductPair(username, product.Name);
                _dbContext.UserProducts.Add(upp);
            }
            else // user added this product multiple times to basket
            {
                if (upp.Amount < product.AmountAvailable) // can't buy more units that there are
                    upp.Amount++;
            }
            _dbContext.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        // 4. Remove product from shopping basket (one/all)
        [HttpGet]
        public IActionResult RemoveOneFromCart(string name)
        {
            return RemoveFromCart(name, 1);
        }

        [HttpGet]
        public IActionResult RemoveAllFromCart(string name)
        {
            return RemoveFromCart(name, -1);
        }

        private RedirectToActionResult RemoveFromCart(string name, int amount)
        {
            _Product? product = _dbContext.Products.FirstOrDefault(p => p.Name == name);
            if (product == null)
                return RedirectToAction(nameof(Index));

            string username = User.Identity!.Name!;
            _UserProductPair? upp = _dbContext.UserProducts
                .FirstOrDefault(up => up.Username == username && up.Productname == product.Name);

            if (upp == null) // user never added this item
                return RedirectToAction(nameof(Index));
            upp.Amount -= amount; // decrease amount in basket by given number
            if (upp.Amount <= 0 || amount == -1) // removed item from basket
                _dbContext.UserProducts.Remove(upp);
            _dbContext.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        // 5. Show user's basket ------------------------------------------------------------------
        [HttpGet]
        public IActionResult ShowBasket()
        {
            List<ProductPair> userBasket =
            [
                .. _dbContext.UserProducts
                    .Where(up => up.Username == User.Identity!.Name)
                    .Select(up => new ProductPair(_dbContext.Products.First(p => p.Name == up.Productname), up.Amount)),
            ];
            return View(userBasket);
        }
    }
}
