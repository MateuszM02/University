﻿using Microsoft.AspNetCore.Mvc;
using Sklep.Models;
using Sklep.Helpers;
using OtpNet;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace Sklep.Controllers
{
    public class GuestController(AppDbContext context) : Controller
    {
        private readonly AppDbContext _dbContext = context;

        // 1.1 Show shop page view
        [HttpGet]
        public IActionResult Index()
        {
            string? roleClaim = User.FindFirst(ClaimTypes.Role)?.Value;
            return roleClaim switch
            {
                null => View( _dbContext.Products.ToList() ), // guest view
                ROLE.User => Redirect($"/{ROLE.User}/{nameof(Index)}"), // user view
                ROLE.Admin => Redirect($"/{ROLE.Admin}/{nameof(Index)}"), // admin view
                _ => throw new InvalidDataException("Guest/Index"),
            };
        }

        // 1.2 When user tries to do something he isn't supposed to
        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        // 1.3 Clicked on product
        [HttpGet]
        public IActionResult ShowProduct(string name)
        {
            _Product? product = _dbContext.Products.FirstOrDefault(p => p.Name == name);
            if (product != null)
                return View(product);
            ModelState.AddModelError("", "Product with given name doesn't exist");
            return RedirectToAction(nameof(Index));
        }

        // 2. Searching shop products -------------------------------------------------------------
        // 2.1 show products which meets criteria
        [HttpPost]
        public IActionResult Search()
        {
            List<_Product> foundProducts = _dbContext.Products
                .Where(MeetsPhrase).ToList();
            return View(nameof(Index), foundProducts);
        }

        // 2.2 Check if product name or description contains searched phrase
        public bool MeetsPhrase(_Product p)
        {
            string searchedPhrase = Request.Form[PATHS.SearchKey]!;
            return p.Name.Contains(searchedPhrase, StringComparison.OrdinalIgnoreCase) ||
                p.Description.Contains(searchedPhrase, StringComparison.OrdinalIgnoreCase);
        }

        // 3. Sign up actions ---------------------------------------------------------------------
        // 3.1 sign up view
        [HttpGet]
        public IActionResult Signup()
        {
            return View();
        }

        // 3.2 verify if given data can create new account 
        [HttpPost]
        public async Task<IActionResult> Signup(SignUpModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(nameof(Signup));
            }

            // check if given name is unique
            if (_dbContext.Users.Any(u => u.Name == model.Username))
            {
                ModelState.AddModelError("", "This username is already taken.");
                return View(nameof(Signup));
            }

            // create User with hashed password
            _User newUser = new()
            {
                Name = model.Username,
                Email = model.Email,
                UserRole = ROLE.User,
            };
            _Password userPassword = new()
            {
                Username = model.Username
            };
            userPassword.Password = userPassword.Hash(model.Password);

            // Add User and password to database
            _dbContext.Users.Add(newUser);
            _dbContext.Passwords.Add(userPassword);
            _dbContext.SaveChanges();

            // set user identity
            return await Login(newUser.Name);
        }

        // 4. Login verification ------------------------------------------------------------------
        // 4.1 login view
        [HttpGet]
        public IActionResult VerifyLogin()
        {
            return View(nameof(Login));
        }

        // 4.2 verify if given data is a valid account 
        [HttpPost]
        public async Task<IActionResult> VerifyLogin(LogInModel model)
        {
            // invalid state - too short/long username or password
            if (!ModelState.IsValid)
            {
                return View(nameof(Login));
            }

            // check if given username exists
            if (!_dbContext.Users.Any(u => u.Name == model.Username))
            {
                ModelState.AddModelError("", "This username doesn't exist.");
                return View(nameof(Login));
            }

            // check if given password is correct
            _Password userPassword = _dbContext.Passwords.First(p => p.Username == model.Username);
            string realHash = userPassword.Password;
            string givenHash = userPassword.Hash(model.Password);

            if (realHash != givenHash)
            {
                ModelState.AddModelError("", "Wrong password.");
                return View(nameof(Login));
            }

            // given password is correct, if user is admin ask for 2nd step verification 
            string role = _dbContext.Users.First(u => u.Name == model.Username).UserRole;
            if (role == ROLE.Admin)
            {
                LoginOtpModel otpModel = new(userPassword.Username, userPassword.OtpKey);
                return View("ShowQR", otpModel);
            }

            // set user identity
            return await Login(model.Username);
        }

        // 4.3 Verify if given Otp code is valid (admin only)
        [HttpPost]
        public async Task<IActionResult> VerifyOTP(LoginOtpModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(nameof(Login));
            }

            Totp totp = new(model.OtpKey); // give real OTP Key
            bool correct = totp.VerifyTotp(model.OtpCode, out _, new VerificationWindow(3)); // User given code

            if (!correct)
            {
                ModelState.AddModelError("", "Wrong Otp code.");
                return View("ShowQR", model);
            }
            return await Login(model.Username);
        }

        // 5. login/logout action -----------------------------------------------------------------
        // 5.1 login verified user
        [HttpPost]
        public async Task<IActionResult> Login(string username)
        {
            _User user = _dbContext.Users.First(u => u.Name == username);

            // create new claim identity
            List<Claim> claims =
            [
                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Role, user.UserRole)
            ];

            ClaimsIdentity identity = new(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            ClaimsPrincipal principal = new(identity);

            // log in user and redirect to main web view
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
            return RedirectToAction(nameof(Index));
        }

        // 5.2. Logout verified user
        [Authorize(Roles = ROLE.UserOrAdmin)]
        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            // log out current user and redirect to main web view
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction(nameof(Index));
        }
    }
}
